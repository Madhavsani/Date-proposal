
import { useState } from "react";
export default function App() {
  const [yes,setYes]=useState(false);
  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'sans-serif'}}>
      {!yes ? <div style={{textAlign:'center'}}><h1>Hey Beautiful ❤️</h1><p>Will you go on a date with me? 🥺❤️</p><button onClick={()=>setYes(true)}>YES 😍</button></div>
      : <div style={{textAlign:'center'}}><h1>WAIT YOU ACTUALLY SAID YES?? 😭❤️</h1><p>I hope one day we create memories together ❤️</p></div>}
    </div>
  )
}
